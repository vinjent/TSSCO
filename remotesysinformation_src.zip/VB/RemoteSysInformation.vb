Imports System
Imports System.Management
Imports System.Globalization
Imports System.Net
Imports Microsoft.Win32

Public Class RemoteSysInformation
#Region "Enum Types"
	Public Enum DriveTypes
		Unknown = 0
		No_Root_Directory = 1
		Removable_Disk = 2
		Local_Disk = 3
		Network_Drive = 4
		Compact_Disc = 5
		RAM_Disk = 6
	End Enum

	Public Enum Status
		Success = 0
		AuthenticateFailure = 1
		UnauthorizedAccess = 2
		RPCServicesUnavailable = 3
	End Enum
#End Region

#Region "structures"
	Public Structure TimezoneInfo
		Public standardname As String
		Public minoffset As Integer
	End Structure

	Public Structure LogicalDrive
		Public name As String
		Public drivetype As DriveTypes
		Public size As UInt64
		Public freespace As UInt64
		Public filesystem As String
	End Structure

	Public Structure IPAddresses
		Public address As IPAddress
		Public subnet As IPAddress
	End Structure

	Public Structure NetworkAdapter
		Public networkaddress() As IPAddresses
		Public DHCPEnabled As Boolean
		Public name As String
		Public databasePath As String
	End Structure

	Public Structure Processor
		Public name As String
		Public speed As UInt32
		Public architecture As String
	End Structure

	Public Structure OperatingSystemVersion
		Public servicepackmajor As UInt32
		Public servicepackminor As UInt32
		Public major As UInt32
		Public minor As UInt32
		Public type As UInt32
		Public build As UInt32
		Public description As String
	End Structure
#End Region

#Region "Variable declarations"
	Private p_extendederror As Integer

	Private p_stderr As System.IO.Stream

	Private p_adapters() As NetworkAdapter

	Private p_bios As String

	Private p_osname As String
	Private p_osmanufacturer As String
	Private p_osversion As OperatingSystemVersion
	Private p_locale As String
	Private p_windowsdirectory As String
	Private p_freephysicalmemory As UInt64
	Private p_totalphysicalmemory As UInt64
	Private p_freevirtualmemory As UInt64
	Private p_totalvirtualmemory As UInt64
	Private p_pagefilesize As UInt64
	Private p_timezone As TimezoneInfo
	Private p_computername As String

	Private p_domain As String
	Private p_systemmanufacturer As String
	Private p_systemmodel As String
	Private p_systemtype As String
	Private p_numberofprocessors As UInt32
	Private p_processors() As Processor

	Private p_drives() As LogicalDrive
#End Region

#Region "Properties"
	Public ReadOnly Property ExtendedError() As Integer
		Get
			Return p_extendederror
		End Get
	End Property

	Public Property stderr() As System.IO.Stream
		Get
			Return p_stderr
		End Get
		Set(ByVal Value As System.IO.Stream)
			If (Not IsNothing(Value) AndAlso Value.CanWrite) Then
				p_stderr = Value
			End If
		End Set
	End Property

	Public ReadOnly Property LogicalDrives() As LogicalDrive()
		Get
			Return p_drives
		End Get
	End Property

	Public ReadOnly Property Bios() As String
		Get
			Return p_bios
		End Get
	End Property

	Public ReadOnly Property Adapters() As NetworkAdapter()
		Get
			Return p_adapters
		End Get
	End Property

	Public ReadOnly Property OSName() As String
		Get
			Return p_osname
		End Get
	End Property

	Public ReadOnly Property OSManufacturer() As String
		Get
			Return p_osmanufacturer
		End Get
	End Property

	Public ReadOnly Property OSVersion() As OperatingSystemVersion
		Get
			Return p_osversion
		End Get
	End Property

	Public ReadOnly Property Locale() As String
		Get
			Return p_locale
		End Get
	End Property

	Public ReadOnly Property WindowsDirectory() As String
		Get
			Return p_windowsdirectory
		End Get
	End Property

	Public ReadOnly Property FreePhysicalMemory() As UInt64
		Get
			Return p_freephysicalmemory
		End Get
	End Property

	Public ReadOnly Property TotalPhysicalMemory() As UInt64
		Get
			Return p_totalphysicalmemory
		End Get
	End Property

	Public ReadOnly Property FreeVirtualMemory() As UInt64
		Get
			Return p_freevirtualmemory
		End Get
	End Property

	Public ReadOnly Property TotalVirtualMemory() As UInt64
		Get
			Return p_totalvirtualmemory
		End Get
	End Property

	Public ReadOnly Property PageFileSize() As UInt64
		Get
			Return p_pagefilesize
		End Get
	End Property

	Public ReadOnly Property Timezone() As TimezoneInfo
		Get
			Return p_timezone
		End Get
	End Property

	Public ReadOnly Property ComputerName() As String
		Get
			Return p_computername
		End Get
	End Property

	Public ReadOnly Property Domain() As String
		Get
			Return p_domain
		End Get
	End Property

	Public ReadOnly Property SystemManufacturer() As String
		Get
			Return p_systemmanufacturer
		End Get
	End Property

	Public ReadOnly Property SystemModel() As String
		Get
			Return p_systemmodel
		End Get
	End Property

	Public ReadOnly Property SystemType() As String
		Get
			Return p_systemtype
		End Get
	End Property

	Public ReadOnly Property NumberOfProcessors() As UInt32
		Get
			Return p_numberofprocessors
		End Get
	End Property

	Public ReadOnly Property Processors() As Processor()
		Get
			Return p_processors
		End Get
	End Property
#End Region

	Public Sub New()
		p_stderr = Nothing
	End Sub

	Public Sub New(ByVal errstrm As System.IO.Stream)
		' Note that we use the property to set this as it
		' does checks on it to make sure it's valid.
		stderr = errstrm
	End Sub

	Public Function [Get](ByVal host As String) As Status
		Return [Get](host, Nothing, Nothing)
	End Function

	Public Function [Get](ByVal host As String, ByVal username As String, ByVal password As String) As Status
		' No blank username's allowed.
		If (username = "") Then
			username = Nothing
			password = Nothing
		End If
		' Configure the connection settings.
		Dim options As ConnectionOptions = New ConnectionOptions
		options.Username = username		 'could be in domain\user format
		options.Password = password
		Dim path As ManagementPath = New ManagementPath(String.Format("\\{0}\root\cimv2", host))
		Dim scope As ManagementScope = New ManagementScope(path, options)

		' Try and connect to the remote (or local) machine.
		Try
			scope.Connect()
		Catch ex As ManagementException
			' Failed to authenticate properly.
			LogError("Failed to authenticate: " + ex.Message)
			p_extendederror = ex.ErrorCode
			Return Status.AuthenticateFailure
		Catch ex As System.Runtime.InteropServices.COMException
			' Unable to connect to the RPC service on the remote machine.
			LogError("Unable to connect to RPC service: " + ex.Message)
			p_extendederror = ex.ErrorCode
			Return Status.RPCServicesUnavailable
		Catch ex As System.UnauthorizedAccessException
			' User not authorized.
			LogError("Unauthorized access: " + ex.Message)
			p_extendederror = 0
			Return Status.UnauthorizedAccess
		End Try

		' Populate the class.
		GetSystemInformation(scope)
		GetNetworkAddresses(scope)
		GetLogicalDrives(scope)

		Return Status.Success
	End Function

	Private Sub LogError(ByVal message As String)
		If (Not IsNothing(p_stderr) AndAlso p_stderr.CanWrite) Then
			Dim bytes() As Byte = System.Text.ASCIIEncoding.ASCII.GetBytes(message)
			p_stderr.Write(bytes, 0, bytes.Length)
		End If
	End Sub

	Private Function GetTimezone(ByVal offset As Integer) As String
		Dim hr As Integer, min As Integer
		Dim search As String, sign As String

		If (offset = 0) Then
			search = "GMT"
		Else
			hr = Math.Abs(offset) / 60
			min = Math.Abs(offset) Mod 60
			If (offset < 0) Then
				sign = "-"
			Else
				sign = "+"
			End If
			search = String.Format("{0}{1:00}:{2:00}", sign, hr, min)

			Dim timeZones As RegistryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows NT\CurrentVersion\Time Zones", True)
			Dim subKeyName As String

			For Each subKeyName In timeZones.GetSubKeyNames()
				Dim tempKey As RegistryKey = timeZones.OpenSubKey(subKeyName)
				Dim standardName As String

				If (tempKey.GetValue("Display").ToString().IndexOf(search) >= 0) Then
					standardName = tempKey.GetValue("Std").ToString()
					tempKey.Close()
					timeZones.Close()
					Return standardName
				End If
			Next
		End If

		Return "<unknown>"
	End Function

	Private Sub GetLogicalDrives(ByVal scope As ManagementScope)
		Dim moSearch As ManagementObjectSearcher = New ManagementObjectSearcher(scope, New ObjectQuery("Select Name, DriveType, Size, FreeSpace, FileSystem from Win32_LogicalDisk Where DriveType = 3 Or DriveType = 6"))
		Dim moReturn As ManagementObjectCollection = moSearch.Get()

		ReDim p_drives(moReturn.Count)
		Dim i As Integer = 0
		Dim mo As ManagementObject

		For Each mo In moReturn
			p_drives(i).drivetype = CType(mo("DriveType").ToString(), DriveTypes)
			p_drives(i).filesystem = mo("FileSystem").ToString()
			p_drives(i).freespace = UInt64.Parse(mo("FreeSpace").ToString())
			p_drives(i).size = UInt64.Parse(mo("Size").ToString())
			p_drives(i).name = mo("Name").ToString()
			i += 1
		Next
	End Sub

	Private Sub GetSystemInformation(ByVal scope As ManagementScope)
		' Only get the first BIOS in the list. Usually this is all there is.
		Dim mo As ManagementObject

		For Each mo In New ManagementClass(scope, New ManagementPath("Win32_BIOS"), Nothing).GetInstances()
			p_bios = mo("Version").ToString()
			Exit For
		Next

		For Each mo In New ManagementClass(scope, New ManagementPath("Win32_OperatingSystem"), Nothing).GetInstances()
			p_osversion.build = UInt32.Parse(mo("BuildNumber").ToString())
			p_osversion.description = String.Format("{0} {1} Build {2}", mo("Version"), mo("CSDVersion"), mo("BuildNumber"))
			p_osversion.servicepackmajor = UInt32.Parse(mo("ServicePackMajorVersion").ToString())
			p_osversion.servicepackminor = UInt32.Parse(mo("ServicePackMinorVersion").ToString())
			p_osversion.type = UInt32.Parse(mo("OSType").ToString())
			' Get the major and minor version numbers.
			Dim numbers() As String = mo("Version").ToString().Split(".".ToCharArray())
			p_osversion.major = UInt32.Parse(numbers(0))
			p_osversion.minor = UInt32.Parse(numbers(1))
			' Get the rest of the fields.
			p_osname = mo("Name").ToString().Split("|".ToCharArray())(0)
			p_osmanufacturer = mo("Manufacturer").ToString()
			p_locale = mo("Locale").ToString()
			p_windowsdirectory = mo("WindowsDirectory").ToString()
			p_freevirtualmemory = UInt64.Parse(mo("FreeVirtualMemory").ToString())
			p_totalvirtualmemory = UInt64.Parse(mo("TotalVirtualMemorySize").ToString())
			p_freephysicalmemory = UInt64.Parse(mo("FreePhysicalMemory").ToString())
			p_totalphysicalmemory = UInt64.Parse(mo("TotalVisibleMemorySize").ToString())
			p_pagefilesize = UInt64.Parse(mo("SizeStoredInPagingFiles").ToString())
			p_computername = mo("CSName").ToString()
			' Get the information related to the timezone.
			p_timezone.minoffset = Integer.Parse(mo("CurrentTimeZone").ToString())
			p_timezone.standardname = GetTimezone(p_timezone.minoffset)
			Exit For
		Next

		For Each mo In New ManagementClass(scope, New ManagementPath("Win32_ComputerSystem"), Nothing).GetInstances()
			p_systemmanufacturer = mo("Manufacturer").ToString()
			p_systemmodel = mo("Model").ToString()
			p_systemtype = mo("SystemType").ToString()
			p_domain = mo("Domain").ToString()
			p_numberofprocessors = UInt32.Parse(mo("NumberOfProcessors").ToString())
			Exit For
		Next

		Dim moSearch As ManagementObjectSearcher = New ManagementObjectSearcher(scope, New ObjectQuery("Select Name, CurrentClockSpeed, Architecture from Win32_Processor"))
		Dim moReturn As ManagementObjectCollection = moSearch.Get()

		ReDim p_processors(moReturn.Count)
		Dim i As Integer = 0
		For Each mo In moReturn
			p_processors(i).name = mo("Name").ToString().Trim()
			p_processors(i).architecture = mo("Architecture").ToString()
			p_processors(i).speed = UInt32.Parse(mo("CurrentClockSpeed").ToString())
			i += 1
		Next
	End Sub

	Private Sub GetNetworkAddresses(ByVal scope As ManagementScope)
		Dim Adapters As ManagementObjectCollection
		Dim search As ManagementObjectSearcher

		search = New ManagementObjectSearcher(scope, New ObjectQuery("Select Description, DHCPEnabled, IPAddress, DatabasePath, IPSubnet from Win32_NetworkAdapterConfiguration Where IPEnabled = True"))
		Adapters = search.Get()

		ReDim p_adapters(Adapters.Count)
		Dim adapter As ManagementObject
		Dim i As Integer = 0, j As Integer

		For Each adapter In Adapters
			p_adapters(i).name = adapter("Description").ToString()
			p_adapters(i).DHCPEnabled = Boolean.Parse(adapter("DHCPEnabled").ToString())
			p_adapters(i).databasePath = adapter("DatabasePath").ToString()

			If (Not IsNothing(adapter("IPAddress"))) Then
				ReDim p_adapters(i).networkaddress(adapter("IPAddress").Length)
				For j = 0 To adapter("IPAddress").Length - 1
					p_adapters(i).networkaddress(j).address = IPAddress.Parse(adapter.Properties("IPAddress").Value(j))
					p_adapters(i).networkaddress(j).subnet = IPAddress.Parse(adapter.Properties("IPSubnet").Value(j))
				Next
			End If
		Next
	End Sub

End Class
