﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceProcess;

namespace GetSystemMonitorDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // Display properties for the System Monitor Demo Service 
            ServiceController sc = new ServiceController("System Monitor Demo");
            Console.WriteLine("ServiceName: " + sc.ServiceName);
            Console.WriteLine("DisplayName: " + sc.DisplayName);
            Console.WriteLine("Status: " + sc.Status);
            Console.WriteLine("ServiceType: " + sc.ServiceType);
            Console.WriteLine("Can Pause and Continue: " + sc.CanPauseAndContinue);
            Console.WriteLine("Can ShutDown: " + sc.CanShutdown);
            Console.WriteLine("Can Stop: " + sc.CanStop);
        }
    }
}
