﻿/******************************************************************************
(C) Copyright 2012  Zuoliu Ding.  All Rights Reserved.
ServiceConfig.cs:	Configuration for System Monitor Service 
Created by:			Zuoliu Ding, 01/01/2012
Note:				Configuration XML object used in serialization 
******************************************************************************/
using System;
using System.Xml.Serialization;

namespace CodeOffice.DingsSystemMonitorService
{
    public class ServiceConfig
    {
        [XmlAttribute()]
        public string ServiceName;
        public int TimeCheckCycle { get; set; }
        public int TimeStartDelay { get; set; }
        public int TimeStopTimeout { get; set; }
        public string[] Hosts;
        public Usage[] Usages;
    }

    public enum DeviceType { CPU, PhysicalMemory, VirtualMemory, DiskSpace };
    public class Usage
    {
        [XmlAttribute()]
        public DeviceType DeviceID;
        [XmlAttribute()]
        public bool Enable;
        [XmlAttribute()]
        public double Threshold;
    }

}
