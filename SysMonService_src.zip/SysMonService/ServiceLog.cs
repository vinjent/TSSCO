﻿/******************************************************************************
(C) Copyright 2012  Zuoliu Ding.  All Rights Reserved.
ServiceLog.cs:	    Logging for System Monitor Service 
Created by:			Zuoliu Ding, 01/01/2012
Note:				A singleton logging utility 
******************************************************************************/
using System;
using System.Text;
using System.IO;
using System.Reflection;
using System.Globalization;

namespace CodeOffice.DingsSystemMonitorService
{
    class Log
    {
        Log() { }  // Constructor is 'private'

        public static Log Instance
        {
            get
            {   // Lazy initialization, this singleton is not thread safe.
                if (_instance == null)
                    _instance = new Log();
                return _instance;
            }
        }

        public void OpenLog() 
        {
            // Retrieve the module path
            string path = Assembly.GetExecutingAssembly().Location;
            int pos = path.IndexOf(".exe");
            path = path.Substring(0, pos);
            pos = path.LastIndexOf('\\');
            ModuleName = path.Substring(pos + 1);

            // Get the week of the year
            DateTimeFormatInfo dfi = DateTimeFormatInfo.CurrentInfo;
            DateTime dt = DateTime.Now;
            int week = dfi.Calendar.GetWeekOfYear(dt, dfi.CalendarWeekRule, dfi.FirstDayOfWeek);

            // Create one log file per week
            path += week + dt.ToString("MMMyyyy") + ".log";
            FileMode fm = File.Exists(path) ? FileMode.Append : FileMode.CreateNew;
            _fileStream = new FileStream(path, fm, FileAccess.Write, FileShare.Read);
            _streamWriter = new StreamWriter(_fileStream);
       }

        public void WriteLine(string LogMsg, bool timeStamp=false)
        {
            if (_streamWriter == null) // Lazy initialization,
                OpenLog();
 
            _streamWriter.BaseStream.Seek(0, SeekOrigin.End);

            string time = "";
            if (timeStamp)
                time = DateTime.Now.ToString("G") + ", ";         
            _streamWriter.WriteLine(time + LogMsg);
        }

        public void Close()
        {
            if (_streamWriter != null)
            {
                _streamWriter.Close();
                _streamWriter = null;
            }

            if (_fileStream != null)
            {
                _fileStream.Close();
                _fileStream = null;
            }
        }

        public string ModuleName { get; set; }

        static Log _instance;
        FileStream _fileStream;
        StreamWriter _streamWriter;

    }
}
