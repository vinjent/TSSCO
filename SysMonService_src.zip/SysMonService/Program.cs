﻿/******************************************************************************
(C) Copyright 2012  Zuoliu Ding.  All Rights Reserved.
Program.cs:		    Main entry point for System Monitor Service
Created by:			Zuoliu Ding, 01/01/2012
Reference:          http://msdn.microsoft.com/en-us/library/y817hyb6.aspx
******************************************************************************/
using System;
using System.ServiceProcess;

namespace CodeOffice.DingsSystemMonitorService
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[] 
            { 
                new SysMonService() 
            };
            ServiceBase.Run(ServicesToRun);
        }
    }
}
