﻿/******************************************************************************
(C) Copyright 2012  Zuoliu Ding.  All Rights Reserved.
ServiceThread.cs:	Threading for System Monitor Service 
Created by:			Zuoliu Ding, 01/01/2012
Note:				Starts and stops a service thread with a thread proc   
******************************************************************************/
using System;
using System.Threading;
using System.Reflection;
using System.IO;
using System.Xml.Serialization;

namespace CodeOffice.DingsSystemMonitorService
{
    public class ServiceThread
    {
        public void Start(string action)
        {
            Log.Instance.OpenLog();
            Log.Instance.WriteLine("===================================================");
            Log.Instance.WriteLine(Log.Instance.ModuleName + " Thread " +action, true);

             _thread = new Thread(ThreadProc);
             _config = _getXmlConfig();
             _thread.Start(this);
        }

        public void Stop(string action)
        {
            _myTimer.Dispose();
            Log.Instance.WriteLine(Log.Instance.ModuleName + " Thread " + action 
                +(_thread.Join(_config.TimeStopTimeout) ? " OK" : " Timeout"), true);
             _config = null;
             Log.Instance.Close();
        }

        // Get the configurations to prepare timer
        internal ServiceConfig _getXmlConfig()
        {
            string path = Assembly.GetExecutingAssembly().Location;
            int pos = path.IndexOf(".exe");
            path = path.Substring(0, pos) + ".xml";

            XmlSerializer x = new XmlSerializer(typeof(ServiceConfig));

            if (!File.Exists(path))   // Create XML at the first time
            {
                _config = new ServiceConfig { 
                    ServiceName = Log.Instance.ModuleName,                                             
                    TimeStartDelay = 2000, TimeCheckCycle = 120000, TimeStopTimeout = 5000,
                    Hosts = new string[] { 
                        "www.google.com", "www.microsoft.com", "www.cnn.com" }
                };

                // DeviceType { CPU, PhysicalMemory, VirtualMemory, DiskSpace };
                double threshold = 10;
                Array ary = Enum.GetValues(typeof(DeviceType));
                _config.Usages = new Usage[ary.Length];
                foreach (DeviceType value in ary)
                {
                    _config.Usages[(int)value]
                        = new Usage { DeviceID = value, Enable = true, Threshold = threshold += 10 };
                }
//                config.Usages[2].Enable = false;   // Disable VirtualMemory
               
                TextWriter w = new StreamWriter(path);
                x.Serialize(w, _config);
                w.Close();
                Log.Instance.WriteLine("Info: Service Configuration created");
            }
            else    // XML configurations Exist
            {
                try
                {
                    TextReader r = new StreamReader(path);
                    _config = x.Deserialize(r) as ServiceConfig;
                    r.Close();
                    Log.Instance.WriteLine("Info: Service Configuration retrieved");
                }
                catch (Exception e)
                {
                    Log.Instance.WriteLine("Error in XmlSerializer TextReader: " + e.Message);
                }
            }

            return _config;
        }

        static void ThreadProc(object o)
        {
            Log.Instance.WriteLine("Thread Proc called");
            ServiceConfig cfg = (o as ServiceThread)._config;
            ServiceWorker sw = new ServiceWorker();
            _myTimer = new Timer(sw.TimerProc, o, cfg.TimeStartDelay, cfg.TimeCheckCycle);
        }

        Thread _thread;
        ServiceConfig _config;
        static Timer _myTimer;
    }
}
