﻿/****************************************************************************************************************
(C) Copyright 2012  Zuoliu Ding.  All Rights Reserved.
ProjectInstaller.cs:Dings System Monitor Service Project Installer
Created by:			Zuoliu Ding, 01/01/2012
Note:				Get CPU and Memory percents for Service 
Reference:          Windows Service Applications, http://msdn.microsoft.com/en-us/library/y817hyb6.aspx
****************************************************************************************************************/
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;


namespace CodeOffice.DingsSystemMonitorService
{
    [RunInstaller(true)]
    public partial class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();
        }
    }
}
