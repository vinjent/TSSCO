﻿/******************************************************************************
(C) Copyright 2012  Zuoliu Ding.  All Rights Reserved.
ServiceWorker.cs:	Tasks working in System Monitor Service 
Created by:			Zuoliu Ding, 01/01/2012
Note:				A timer delegate called in the thread proc   
******************************************************************************/
using System;
using System.Net;
using System.Threading;

namespace CodeOffice.DingsSystemMonitorService
{
    internal class ServiceWorker
    {
        // This method is called by the timer delegate.
        internal void TimerProc(Object o)
        {
            Log.Instance.WriteLine("Timer Proc Started ... ...", true);
            ServiceConfig cfg = (o as ServiceThread)._getXmlConfig();

            string s = "";
            Log.Instance.WriteLine("------ Check Remote Hosts ------");
            foreach (string host in cfg.Hosts)
            {
                try
                {
                    IPHostEntry hostInfo = Dns.GetHostEntry(host);   
                    Thread.Sleep(1000); 
                    Log.Instance.WriteLine("Check " +host +", Host name:" + hostInfo.HostName);
 
                    s = ""; 
                    foreach (IPAddress ip in hostInfo.AddressList)
                        s += "(" +ip.ToString() +") ";
                    Log.Instance.WriteLine("IP: " + s);
                }         
                catch (Exception e)
                {
                    Log.Instance.WriteLine("Check " +host + ", Error: " + e.Message);
                }
            }

            Log.Instance.WriteLine("----- Check Local Computer -----");
            foreach (Usage u in cfg.Usages)
            {
                if (!u.Enable)
                    continue;

                switch (u.DeviceID)
                {
                    case DeviceType.CPU:
                        double d = _SysData.GetProcessorData();
                        Log.Instance.WriteLine("CPU Used " + d.ToString("F") + "%"
                            + (d >= u.Threshold ? " Over Threshold(" + u.Threshold + ")" : ""));
                        break;

                    case DeviceType.DiskSpace:
                        Log.Instance.WriteLine("Disk Space:");
                        foreach (SysValues v in _SysData.GetDiskSpaces())
                            LogSysValueWithUsage(v, u);
                        break;

                    case DeviceType.PhysicalMemory:
                        LogSysValueWithUsage(_SysData.GetPhysicalMemory(), u);
                        break;

                    case DeviceType.VirtualMemory:
                         LogSysValueWithUsage(_SysData.GetVirtualMemory(), u);
                        break;
                }
            }

            Log.Instance.WriteLine("Timer Proc Ended ... ...", true);
            Log.Instance.WriteLine("---------------------------------------------------");
            Log.Instance.Close();
        } // TimerProc

        void LogSysValueWithUsage(SysValues val, Usage usage)
        {
            double d = 100 * val.Used / val.Total;
            string s = (d >= usage.Threshold ? " Over Threshold(" + usage.Threshold + ")" : "");
            Log.Instance.WriteLine(val.DeviceID + " " + d.ToString("F") + "% ("
                + FormatBytes(double.Parse(val.Used.ToString())) + "/"
                + FormatBytes(double.Parse(val.Total.ToString())) + ")" + s);
        }

        enum Unit { B, KB, MB, GB, TB, ER }
        string FormatBytes(double bytes)
        {
            int unit = 0;
            while (bytes > 1024)
            {
                bytes /= 1024;
                ++unit;
            }

            return bytes.ToString("F") +" "+ ((Unit)unit).ToString();
        }

        SystemData _SysData = new SystemData();
    }
}
