/******************************************************************************
(C) Copyright 2012  Zuoliu Ding.  All Rights Reserved.
SysData.cs:		    From SystemData.cs in "An Implementation of System Monitor"
Created by:			Zuoliu Ding, 01/01/2012
Note:				Get CPU and Memory percents for Service 
Reference:          http://www.codeproject.com/KB/miscctrl/SystemMonitor.aspx 
******************************************************************************/
using System;
using System.Diagnostics;
using System.Management;
using System.Collections.Generic;

namespace CodeOffice.DingsSystemMonitorService
{
    public class SystemData
    {
        #region "Public Methods"
        public double GetProcessorData()
        {
            return _GetCounterValue(_cpuCounter, "Processor", "% Processor Time", "_Total");
        }

        public SysValues GetVirtualMemory()
        {
            double d = _GetCounterValue(_memoryCounter, "Memory", "Committed Bytes", null);
            double totalphysicalmemory = _GetCounterValue(_memoryCounter, "Memory", "Commit Limit", null);
            return new SysValues { DeviceID = "Virtual Memory", Total = totalphysicalmemory, Used = d };
        }

        public SysValues GetPhysicalMemory()
        {
            string s = _QueryComputerSystem("totalphysicalmemory");
            double totalphysicalmemory = Convert.ToDouble(s);
            double d = _GetCounterValue(_memoryCounter, "Memory", "Available Bytes", null);
            return new SysValues { DeviceID = "Physical Memory", Total = totalphysicalmemory, Used = totalphysicalmemory - d };
        }

        public List<SysValues> GetDiskSpaces()
        {
            List<SysValues> disks = new List<SysValues>();
            object device, size, free;
            double totle;
            ManagementObjectSearcher objCS = new ManagementObjectSearcher("SELECT * FROM Win32_LogicalDisk");
            foreach (ManagementObject objMgmt in objCS.Get())
            {
                device = objMgmt["DeviceID"];		// C:
                if (null != device)
                {
                    size = objMgmt["Size"];
                    free = objMgmt["FreeSpace"];	// C:10.32 GB, D:5.87GB
                    if (null != free && null != size)
                    {
                        totle = double.Parse(size.ToString());
                        disks.Add(new SysValues { DeviceID = device.ToString(), Total = totle, Used = totle - double.Parse(free.ToString()) });
                    }
                }
            }

            return disks;
        }
        #endregion

        #region "Private Helpers"
        double _GetCounterValue(PerformanceCounter pc, string categoryName, string counterName, string instanceName)
        {
            pc.CategoryName = categoryName;
            pc.CounterName = counterName;
            pc.InstanceName = instanceName;
            return pc.NextValue();	
        }

        string _QueryComputerSystem(string type)
        {
            string str = null;
            ManagementObjectSearcher objCS = new ManagementObjectSearcher("SELECT * FROM Win32_ComputerSystem");
            foreach (ManagementObject objMgmt in objCS.Get())
            {
                str = objMgmt[type].ToString();
            }
            return str;
        }
        #endregion

        #region "Members"
        PerformanceCounter _memoryCounter = new PerformanceCounter();	
        PerformanceCounter _cpuCounter = new PerformanceCounter();	
        #endregion
    }

    public class SysValues
    {
        public string DeviceID { get; set; }
        public double Total { get; set; }
        public double Used { get; set; }
    }
}
        

