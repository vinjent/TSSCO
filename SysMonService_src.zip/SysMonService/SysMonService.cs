﻿/******************************************************************************
(C) Copyright 2012  Zuoliu Ding.  All Rights Reserved.
SysMonService.cs:	Main interactive with the Services Control Manager
Created by:			Zuoliu Ding, 01/01/2012
Reference:          http://msdn.microsoft.com/en-us/library/y817hyb6.aspx
******************************************************************************/
using System;
using System.ServiceProcess;

namespace CodeOffice.DingsSystemMonitorService
{
    public partial class SysMonService : ServiceBase
    {
        public SysMonService()
        {
            InitializeComponent();
            this.AutoLog = false;
            this.CanPauseAndContinue = true;
            _paused = false;
        }

        protected override void OnStart(string[] args)
        {
            // to Application event logs
            EventLog.WriteEntry("Dings System Monitor Started.");

            _paused = false;
            _serviceThread = new ServiceThread();
            _serviceThread.Start("Started");
        }

        protected override void OnStop()
        {
            // to Application event logs
            EventLog.WriteEntry("Dings System Monitor Stopped.");

            if (!_paused)
                _serviceThread.Stop("Stopped");
        }

        protected override void OnPause()
        {
            EventLog.WriteEntry("Dings System Monitor Paused.");

            _serviceThread.Stop("Paused");
            _paused = true;
        }

        protected override void OnContinue()
        {
            EventLog.WriteEntry("Dings System Monitor Resumed.");

            _paused = false;
            _serviceThread = new ServiceThread();
            _serviceThread.Start("Resumed");
        }

        ServiceThread _serviceThread;
        bool _paused; 
    }
}
