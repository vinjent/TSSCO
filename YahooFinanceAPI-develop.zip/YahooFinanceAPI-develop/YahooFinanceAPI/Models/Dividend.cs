﻿using System;

namespace YahooFinanceAPI.Models
{
    public class Dividend
    {
        public DateTime Date { get; set; }
        public double Div { get; set; }
    }
}