﻿using MaasOne.Base;
using MaasOne.Finance.YahooFinance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reactive.Threading.Tasks;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CEP
{
    class Program
    {

        static QuoteStream allQuotes;
        static QuoteView appleView;
        static QuoteSlidingWindow slidingWindow;
        static QuoteTumblingWindow tumblingWindow;

        static void Main(string[] args)
        {
            try
            {
                var cts = new CancellationTokenSource();
                allQuotes = new QuoteStream(100);
                appleView = new QuoteView("AppleView");
                slidingWindow = new QuoteSlidingWindow("Apple5MinSlidingWindow", new TimeSpan(0, 5, 0));
                tumblingWindow = new QuoteTumblingWindow("Apple5MinTumblingWindow", new TimeSpan(0, 5, 0));

                appleView.SubscribeTo(allQuotes.Where(x => x.ID == "S68.SI"));
                
                slidingWindow.SubscribeTo(appleView);
                slidingWindow.Subscribe(Indicators.TWAP);

                tumblingWindow.SubscribeTo(appleView);
                tumblingWindow.Subscribe(Indicators.VWAP);


                var repeatingTask = DelayAsync(1000, 100, cts.Token);

                Console.WriteLine("press <ENTER> to unsubscribe from the feed");
                Console.ReadLine();


                cts.Cancel(false);
                repeatingTask.Wait();
            }
            catch (AggregateException ex)
            {
                ex.Handle(e => e is TaskCanceledException);
            }

            Console.WriteLine("press <ENTER> to exit");
            Console.ReadLine();
        }


        static async Task DelayAsync(int delayMillis, int repeatMillis, CancellationToken ct)
        {
            try
            {
                Console.WriteLine("LocalTime={0}: Launching with 2 sec delay", DateTime.Now);

                await Task.Delay(delayMillis, ct);

                Console.WriteLine("LocalTime={0}: Repeating every 1 sec", DateTime.Now);
                while (true)
                {
                    allQuotes.Drain();
                    foreach (var quote in FetchData(Symbols.NASDAQ100))
                        allQuotes.OnNext(quote);

                    await Task.Delay(repeatMillis, ct);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                allQuotes.EndTransmission();
            }
        }



        static QuotesData[] FetchData(string[] symbols)
        {
            QuotesDownload dl = new QuotesDownload();
            DownloadClient<QuotesResult> baseDl = dl;

            QuotesDownloadSettings settings = dl.Settings;

            settings.IDs = symbols;
            
            settings.Properties = new QuoteProperty[] { QuoteProperty.Symbol,
                                            QuoteProperty.Name, 
                                            QuoteProperty.LastTradePriceOnly,
                                            QuoteProperty.LastTradeDate,
                                            QuoteProperty.LastTradeTime,
                                            QuoteProperty.LastTradeSize,
                                          };
            SettingsBase baseSettings = baseDl.Settings;

            Response<QuotesResult> resp = baseDl.Download();

            return resp.Result.Items;
        }

      

    }
}
