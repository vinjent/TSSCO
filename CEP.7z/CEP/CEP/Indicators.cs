﻿using MaasOne.Finance.YahooFinance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CEP
{
    class Indicators
    {

        public static void TWAP(IList<QuotesData> quotes)
        {
            twap(quotes);
        }

        /// <summary>
        /// Time weighted average price for a window of quotes is in this case avergae of the population as argued here:
        /// https://www.tradestation.com/education/labs/analysis-concepts/time-weighted-average-price
        /// </summary>
        /// <param name="quotes">The window over which to calculate TWAP</param>
        /// <returns>TWAP or NaN</returns>
        private static double twap(IList<QuotesData> quotes)
        {

            if (quotes.Count > 0)
            {
                DateTime max = DateTime.MinValue;
                DateTime min = DateTime.MaxValue;
                string ticker = quotes[0].ID;
                double totalPrice = 0.0;
                int n = quotes.Count;
                double twap = 0.0;

                foreach (var q in quotes)
                {
                    totalPrice += q.LastTradePriceOnly;

                    if (q.LastTradeTime > max)
                        max = q.LastTradeTime;
                    if (q.LastTradeTime < min)
                        min = q.LastTradeTime;
                }

                if (n > 0 & totalPrice > 0.0)
                {
                    twap = totalPrice / n;

                    Console.WriteLine("Ticker={0}, TWAP={1} Start={2} End={3}, ", ticker, twap.ToString("2"),
                        min.ToString("yyyy-MMM-dd HH:mm:ss"), max.ToString("yyyy-MMM-dd HH:mm:ss"));

                    return twap;
                }

            }

            return double.NaN;

        }


        public static void VWAP(IList<QuotesData> quotes)
        {
            vwap(quotes);
        }

        /// <summary>
        /// Volume weighted average price as defined by wikipedia http://en.wikipedia.org/wiki/Volume-weighted_average_price
        /// </summary>
        /// <param name="quotes">The window over which to calculate VWAP</param>
        /// <returns>VAP or NaN</returns>
        private static double vwap(IList<QuotesData> quotes)
        {
            if (quotes.Count > 0)
            {
                DateTime max = DateTime.MinValue;
                DateTime min = DateTime.MaxValue;
                string ticker = quotes[0].ID;
                double totalWeightedPrice = 0.0;
                double totalQuantity = 0.0;
                double vwap = 0.0;

                foreach (var q in quotes)
                {
                    double quantity = (double)q.Values(QuoteProperty.LastTradeSize);
                    totalWeightedPrice += (q.LastTradePriceOnly * quantity);
                    totalQuantity += quantity;

                    if (q.LastTradeTime > max)
                        max = q.LastTradeTime;
                    if (q.LastTradeTime < min)
                        min = q.LastTradeTime;
                }

                if (totalQuantity > 0 & totalWeightedPrice > 0.0)
                {
                    vwap = totalWeightedPrice / totalQuantity;

                    Console.WriteLine("Ticker={0}, VWAP={1} Start={2} End={3}, ", ticker, vwap.ToString("2"),
                        min.ToString("yyyy-MMM-dd HH:mm:ss"), max.ToString("yyyy-MMM-dd HH:mm:ss"));

                    return vwap;
                }

            }

            return double.NaN;

        }


    }
}
