﻿using MaasOne.Finance.YahooFinance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CEP
{
    public class QuoteTumblingWindow: QuoteWindow
    {

        public QuoteTumblingWindow(string name, TimeSpan windowLength, int maxLength)
            : base(name, windowLength, maxLength){}

        public QuoteTumblingWindow(string name, TimeSpan windowLength) 
            : base(name, windowLength, int.MaxValue){}

        public override void OnNext(QuotesData value)
        {

            //does this new value complete the current window? If so publish and then reset.
            if (DataStream.Count > 0)
            {
                if (value.LastTradeTime - WindowStart >= WindowLength)
                {
                    foreach (var observer in Observers)
                        observer.OnNext(DataStream.ToList());
                    DataStream.Clear();
                }
            }

            //start a new window
            if (DataStream.Count == 0)
                WindowStart = value.LastTradeTime;

            DataStream.Enqueue(value);

            Console.WriteLine("The QuoteTumblingWindow {0}, contains {1} elements", Name, DataStream.Count);
            foreach (var quote in DataStream)
            {
                Console.WriteLine("QuoteTime={0}\tTicker={1}\tPrice={2}", quote.LastTradeTime, quote.ID, quote.LastTradePriceOnly);
            }
        }

      

    }
}
