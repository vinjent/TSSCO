﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MaasOne;
using MaasOne.Base;
using MaasOne.Finance;
using MaasOne.Finance.YahooFinance;

namespace CEP
{
    public class QuoteStream : IObservable<QuotesData>
    {
        protected List<IObserver<QuotesData>> Observers { get; set; }
        protected Queue<QuotesData> DataStream { get; set; }
        protected int MaxLength { get; private set; }
               
        public QuoteStream()
        {
            Initialise(int.MaxValue);
        }

        public QuoteStream(int maxLength)
        {
            Initialise(maxLength);
        }

        private void Initialise(int maxLength)
        {
            MaxLength = maxLength;
            DataStream = new Queue<QuotesData>();
            Observers = new List<IObserver<QuotesData>>();
        }

        public IDisposable Subscribe(IObserver<QuotesData> observer)
        {
            if (!Observers.Contains(observer))
                Observers.Add(observer);
            return new StreamUnsubscriber(Observers, observer);
        }

        public IList<QuotesData> Drain()
        {
            var drained = new List<QuotesData>();
            while (DataStream.Count > 0)
            {
                drained.Add(DataStream.Dequeue());
            }
            return drained;
        }

        public IList<QuotesData> GetData()
        {
            var data = DataStream.ToList();
            return data;
        }

        public void EndTransmission()
        {
            foreach (var observer in Observers.ToArray())
                if (Observers.Contains(observer))
                    observer.OnCompleted();

            Observers.Clear();
        }

        public virtual void OnNext(QuotesData value)
        {
            if (DataStream.Count + 1 >= MaxLength)
                DataStream.Dequeue();
            else
            {
                DataStream.Enqueue(value);
                foreach (var observer in Observers)
                {
                    observer.OnNext(value);
                }
            }

        }


        private class StreamUnsubscriber : IDisposable
        {
            private List<IObserver<QuotesData>> _observers;
            private IObserver<QuotesData> _observer;

            public StreamUnsubscriber(List<IObserver<QuotesData>> observers, IObserver<QuotesData> observer)
            {
                this._observers = observers;
                this._observer = observer;
            }

            public void Dispose()
            {
                if (_observer != null && _observers.Contains(_observer))
                    _observers.Remove(_observer);
            }
        }


    }


}
