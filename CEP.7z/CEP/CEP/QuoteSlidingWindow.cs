﻿using MaasOne.Finance.YahooFinance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CEP
{
    public class QuoteSlidingWindow : QuoteWindow
    {
        public QuoteSlidingWindow(string name, TimeSpan windowLength, int maxLength)
            : base(name, windowLength, maxLength) { }

        public QuoteSlidingWindow(string name, TimeSpan windowLength)
            : base(name, windowLength, int.MaxValue) { }

        public override void OnNext(QuotesData value)
        {

            DataStream.Enqueue(value);

            if (DataStream.Count > 0)
            {
                var latestQuoteTime = DataStream.Max(x => x.LastTradeTime);
                bool publish = false;

                //find and remove quotes that are now outside of the sliding window
                while (DataStream.Count > 0)
                {
                    var first = DataStream.Peek();
                    if (latestQuoteTime - first.LastTradeTime >= WindowLength)
                    {
                        DataStream.Dequeue();
                        publish = true;
                    }
                    else
                        break;
                }

                //we publish to subscribers only if a quote is exiting the window period
                if (publish)
                {
                    foreach (var observer in Observers)
                        observer.OnNext(DataStream.ToList());
                }
            }


            Console.WriteLine("The QuoteSlidingWindow {0}, contains {1} elements", Name, DataStream.Count);
            foreach (var quote in DataStream)
            {
                Console.WriteLine("QuoteTime={0}\tTicker={1}\tPrice={2}", quote.LastTradeTime, quote.ID, quote.LastTradePriceOnly);
            }
        }

    }
}
