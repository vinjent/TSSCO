﻿using MaasOne.Finance.YahooFinance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CEP
{
    public class QuoteView : QuoteStream, IObserver<QuotesData>
    {
        DateTime _lastQuoteDateTime = DateTime.MinValue;
        private IDisposable _unsubscriber;
        private string _name;

        public QuoteView(int maxLength, string name) : base(maxLength) {
            _name = name;
        }
        public QuoteView(string name) : base() {
            _name = name;
        }


        public virtual void SubscribeTo(IObservable<QuotesData> provider)
        {
            if (provider != null)
                _unsubscriber = provider.Subscribe(this);
        }


        public virtual void OnCompleted()
        {
            Console.WriteLine("The underlying Stream has completed transmitting data to {0}.", _name);
            Unsubscribe();
            foreach (var observer in Observers.ToArray())
                if (Observers.Contains(observer))
                    observer.OnCompleted();
        }

        public virtual void OnError(Exception e)
        {
            Console.WriteLine("{0}: general error", _name);
        }

        public override void OnNext(QuotesData value)
        {
            if (value.LastTradeTime > _lastQuoteDateTime)
            {
                DataStream.Enqueue(value);
                Console.WriteLine("The QuoteView {0}, contains {1} elements", _name, DataStream.Count);
                foreach (var observer in Observers)
                        observer.OnNext(value);

            }

            _lastQuoteDateTime = value.LastTradeTime;

        }

        public virtual void Unsubscribe()
        {
            _unsubscriber.Dispose();
        }
    }
}
