﻿using MaasOne.Finance.YahooFinance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CEP
{
    public abstract class QuoteWindow: IObserver<QuotesData>, IObservable<IList<QuotesData>>
    {
        protected List<IObserver<IList<QuotesData>>> Observers { get; set; }
        private IDisposable _unsubscriber;
        
        protected Queue<QuotesData> DataStream {get; set;}
        protected int MaxLength {get; private set;}
        protected TimeSpan WindowLength {get; private set;}
        protected DateTime WindowStart {get; set;}
        
        
        public string Name { get; private set; }

        public QuoteWindow(string name, TimeSpan windowLength, int maxLength)
        {
            Initialise(name, windowLength, maxLength);
        }

        public QuoteWindow(string name, TimeSpan windowLength)
        {
            Initialise(name, windowLength, int.MaxValue);
        }

        private void Initialise(string name, TimeSpan windowLength, int maxLength)
        {
            WindowStart = DateTime.MinValue;
            Name =name;
            WindowLength = windowLength;
            MaxLength = maxLength;
            DataStream = new Queue<QuotesData>();
            Observers = new List<IObserver<IList<QuotesData>>>();
        }

        public IDisposable Subscribe(IObserver<IList<QuotesData>> observer)
        {
            if (!Observers.Contains(observer))
                Observers.Add(observer);
            return new WindowUnsubscriber(Observers, observer);
        }

        public virtual void SubscribeTo(IObservable<QuotesData> provider)
        {
            if (provider != null)
                _unsubscriber = provider.Subscribe(this);
        }


        public abstract void OnNext(QuotesData value);

        public virtual void OnCompleted()
        {
            Console.WriteLine("The underlying Stream has completed transmitting data to {0}.", Name);
            this.Unsubscribe();
        }

        public virtual void OnError(Exception e)
        {
            Console.WriteLine("{0}: general error", Name);
        }

        public virtual void Unsubscribe()
        {
            _unsubscriber.Dispose();
        }


        private class WindowUnsubscriber : IDisposable
        {
            private List<IObserver<IList<QuotesData>>> _observers;
            private IObserver<IList<QuotesData>> _observer;

            public WindowUnsubscriber(List<IObserver<IList<QuotesData>>> observers, IObserver<IList<QuotesData>> observer)
            {
                this._observers = observers;
                this._observer = observer;
            }

            public void Dispose()
            {
                if (_observer != null && _observers.Contains(_observer))
                    _observers.Remove(_observer);
            }
        }

    }
}
