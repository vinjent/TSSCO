﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Runtime.InteropServices;
using System.Management.Instrumentation;
using System.Security;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Management.Infrastructure.Options;
using Microsoft.Management.Infrastructure;

namespace testRemoteCUP
{
    class Program
    {
        public const int LOGON32_LOGON_INTERACTIVE = 2;
        public const int LOGON32_LOGON_SERVICE = 3;
        public const int LOGON32_PROVIDER_DEFAULT = 0;

        [DllImport("advapi32.dll", CharSet = CharSet.Auto)]
        public static extern bool LogonUser(
            String lpszUserName,
            String lpszDomain,
            String lpszPassword,
            int dwLogonType,
            int dwLogonProvider,
            ref IntPtr phToken);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        public extern static bool CloseHandle(IntPtr handle);

        static void Main(string[] args)
        {
            //IntPtr userHandle = new IntPtr(0);
            //LogonUser("ptu", "tssco.tsh.com.tw", "!QAZ2wsx", LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, ref userHandle);
            //WindowsIdentity identity = new WindowsIdentity(userHandle);
            //WindowsImpersonationContext context = identity.Impersonate();
            //PerformanceCounterCategory cat = new PerformanceCounterCategory("Processor", "172.24.26.39");
            //List<PerformanceCounter> counters = new List<PerformanceCounter>();
            //foreach (string instance in cat.GetInstanceNames())
            //    counters.Add(new PerformanceCounter("Processor", "% Processor Time", instance, "MachineA"));
            //for (int i = 0; i < 10000; i++)
            //{
            //    foreach (PerformanceCounter counter in counters)
            //        Console.Write(counter.NextValue() + " ");
            //}
            //context.Undo();


            //WMI_Library lib = new WMI_Library();
            //lib.CreateSearchScope("172.24.26.122", ".\tssptu", "1QAZ2wsx!@");
            //WMI_Library.Win32_Processor info = lib.GetCPUInformation(0);
            //Console.WriteLine(info.Caption);
            //Console.ReadLine();



            ConnectionOptions options = new ConnectionOptions();
            options.Impersonation = System.Management.ImpersonationLevel.Impersonate;
            options.Authentication = AuthenticationLevel.Default;
            options.Username = "ptu";
            options.Password = "!QAZ2wsx";
            options.Authority = "ntlmdomain:LOCAL";
            options.EnablePrivileges = true;
            //string Password = "!QAZ2wsx";
            //SecureString securepassword = new SecureString();
            //foreach (char c in Password)
            //    securepassword.AppendChar(c);
            //options.SecurePassword = securepassword;
            ManagementScope scope = new ManagementScope("\\\\LOCAL-OPSERVER\\root\\cimv2", options);
            try
            {
                scope.Connect();

                //Query system for Operating System information
                ObjectQuery query = new ObjectQuery("SELECT * FROM Win32_OperatingSystem");
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(scope, query);

                ManagementObjectCollection queryCollection = searcher.Get();
                foreach (ManagementObject m in queryCollection)
                {
                    // Display the remote computer information
                    Console.WriteLine("Computer Name     : {0}", m["csname"]);
                    Console.WriteLine("Windows Directory : {0}", m["WindowsDirectory"]);
                    Console.WriteLine("Operating System  : {0}", m["Caption"]);
                    Console.WriteLine("Version           : {0}", m["Version"]);
                    Console.WriteLine("Manufacturer      : {0}", m["Manufacturer"]);
                }
            }
            catch(Exception ex)
            {

            }


            //string computer = "TSS_J1060020";
            //string domain = "TSSCO";
            //string username = ".\tssptu";


            //string plaintextpassword;

            //Console.WriteLine("Enter password:");
            //plaintextpassword = Console.ReadLine();

            //SecureString securepassword = new SecureString();
            //foreach (char c in plaintextpassword)
            //{
            //    securepassword.AppendChar(c);
            //}

            //// create Credentials
            //CimCredential Credentials = new CimCredential(PasswordAuthenticationMechanism.Default,
            //                                              domain,
            //                                              username,
            //                                              securepassword);

            //// create SessionOptions using Credentials
            //WSManSessionOptions SessionOptions = new WSManSessionOptions();
            //SessionOptions.AddDestinationCredentials(Credentials);

            //// create Session using computer, SessionOptions
            //CimSession Session = CimSession.Create(computer, SessionOptions);

            //var allVolumes = Session.QueryInstances(@"root\cimv2", "WQL", "SELECT * FROM Win32_Volume");
            //var allPDisks = Session.QueryInstances(@"root\cimv2", "WQL", "SELECT * FROM Win32_DiskDrive");

            //// Loop through all volumes
            //foreach (CimInstance oneVolume in allVolumes)
            //{
            //    // Show volume information

            //    if (oneVolume.CimInstanceProperties["DriveLetter"].ToString()[0] > ' ')
            //    {
            //        Console.WriteLine("Volume ‘{0}’ has {1} bytes total, {2} bytes available",
            //                          oneVolume.CimInstanceProperties["DriveLetter"],
            //                          oneVolume.CimInstanceProperties["Size"],
            //                          oneVolume.CimInstanceProperties["SizeRemaining"]);
            //    }

            //}

            //// Loop through all physical disks
            //foreach (CimInstance onePDisk in allPDisks)
            //{
            //    // Show physical disk information
            //    Console.WriteLine("Disk {0} is model {1}, serial number {2}",
            //                      onePDisk.CimInstanceProperties["DeviceId"],
            //                      onePDisk.CimInstanceProperties["Model"].ToString().TrimEnd(),
            //                      onePDisk.CimInstanceProperties["SerialNumber"]);
            //}


            Console.ReadLine();
        }
    }

    public class WMI_Library 
    { 
         public class Win32_Processor 
         { 
           public int Architecture; 
           public int Availability; 
           public string Caption = string.Empty; 
           public int ConfigManagerErrorCode; 
           public bool ConfigManagerUserConfig; 
           public int CpuStatus; 
           public string CreationClassName = string.Empty; 
           public int CurrentClockSpeed; 
           public int CurrentVoltage; 
           public int DataWidth; 
           public string Description; 
           public string DeviceID; 
           public bool ErrorCleared; 
           public string ErrorDescription; 
           public int ExtClock; 
           public int Family; 
           public System.DateTime InstallDate; 
           public int L2CacheSize; 
           public int L2CacheSpeed; 
           public int LastErrorCode; 
           public int Level; 
           public int LoadPercentage; 
           public string Manufacturer; 
           public int MaxClockSpeed; 
           public string Name; 
           public string OtherFamilyDescription; 
           public string PNPDeviceID; 
           public bool PowerManagementSupported; 
           public string ProcessorId; 
           public int ProcessorType; 
           public int Revision; 
           public string Role; 
           public string SocketDesignation; 
           public string Status; 
           public int StatusInfo; 
           public string Stepping; 
           public string SystemCreationClassName; 
           public string SystemName; 
           public string UniqueId; 
           public int UpgradeMethod; 
           public string Version; 
           public int VoltageCaps; 
         } 

         private ManagementScope _searchScope; 

         public void CreateSearchScope(string computerName, string userName, string password) 
         { 
           bool isSameMachine = (computerName.Length == 0); 
           if (!(isSameMachine)) { 
             ManagementPath pathSearch = new ManagementPath("\\\\" + computerName + "\\Root\\CIMV2"); 
             _searchScope = new ManagementScope(pathSearch); 
             _searchScope.Options.Username = userName; 
             _searchScope.Options.Password = password;
             _searchScope.Connect();
           } 
         } 

         public Win32_Processor GetCPUInformation(int index) 
         { 
           ArrayList listCPUs = new ArrayList(); 
           string query = "Select * From Win32_Processor"; 
           ManagementObjectSearcher searchCPU = new ManagementObjectSearcher(query);
           Console.WriteLine(_searchScope.IsConnected);
           if (!(_searchScope == null)) 
             searchCPU.Scope = _searchScope;
           searchCPU.Scope.Connect();
           foreach (ManagementObject entryCurrent in searchCPU.Get()) 
            { 
                 Win32_Processor cpuInfo = new Win32_Processor(); 
                 cpuInfo.Architecture = Convert.ToInt32(entryCurrent["Architecture"]); 
                 cpuInfo.Availability = Convert.ToInt32(entryCurrent["Availability"]); 
                 cpuInfo.Caption = entryCurrent["Caption"].ToString(); 
                 cpuInfo.ConfigManagerErrorCode = Convert.ToInt32(entryCurrent["ConfigManagerErrorCode"]); 
                 cpuInfo.ConfigManagerUserConfig = bool.Parse(entryCurrent["ConfigManagerUserConfig"].ToString()); 
                 cpuInfo.CpuStatus = Convert.ToInt32(entryCurrent["CpuStatus"]); 
                 cpuInfo.CreationClassName = entryCurrent["CreationClassName"].ToString(); 
                 cpuInfo.CurrentClockSpeed = Convert.ToInt32(entryCurrent["CurrentClockSpeed"]); 
                 cpuInfo.CurrentVoltage = Convert.ToInt32(entryCurrent["CurrentVoltage"]); 
                 cpuInfo.DataWidth = Convert.ToInt32(entryCurrent["DataWidth"]); 
                 cpuInfo.Description = entryCurrent["Description"].ToString(); 
                 cpuInfo.DeviceID = entryCurrent["DeviceID"].ToString(); 
                 cpuInfo.ErrorCleared = bool.Parse(entryCurrent["ErrorCleared"].ToString()); 
                 cpuInfo.ErrorDescription = entryCurrent["ErrorDescription"].ToString(); 
                 cpuInfo.ExtClock = Convert.ToInt32(entryCurrent["ExtClock"]); 
                 cpuInfo.Family = Convert.ToInt32(entryCurrent["Family"]); 
                 cpuInfo.InstallDate = DateTime.Parse(entryCurrent["InstallDate"].ToString()); 
                 cpuInfo.L2CacheSize = Convert.ToInt32(entryCurrent["L2CacheSize"]); 
                 cpuInfo.L2CacheSpeed = Convert.ToInt32(entryCurrent["L2CacheSpeed"]); 
                 cpuInfo.LastErrorCode = Convert.ToInt32(entryCurrent["LastErrorCode"]); 
                 cpuInfo.Level = Convert.ToInt32(entryCurrent["Level"]); 
                 cpuInfo.LoadPercentage = Convert.ToInt32(entryCurrent["LoadPercentage"]); 
                 cpuInfo.Manufacturer = entryCurrent["Manufacturer"].ToString(); 
                 cpuInfo.MaxClockSpeed = Convert.ToInt32(entryCurrent["MaxClockSpeed"]); 
                 cpuInfo.Name = entryCurrent["Name"].ToString(); 
                 cpuInfo.OtherFamilyDescription = entryCurrent["OtherFamilyDescription"].ToString(); 
                 cpuInfo.PNPDeviceID = entryCurrent["PNPDeviceID"].ToString(); 
                 cpuInfo.PowerManagementSupported = bool.Parse(entryCurrent["PowerManagementSupported"].ToString()); 
                 cpuInfo.ProcessorId = entryCurrent["ProcessorId"].ToString(); 
                 cpuInfo.ProcessorType = Convert.ToInt32(entryCurrent["ProcessorType"]); 
                 cpuInfo.Revision = Convert.ToInt32(entryCurrent["Revision"]); 
                 cpuInfo.Role = entryCurrent["Role"].ToString(); 
                 cpuInfo.SocketDesignation = entryCurrent["SocketDesignation"].ToString(); 
                 cpuInfo.Status = entryCurrent["Status"].ToString(); 
                 cpuInfo.StatusInfo = Convert.ToInt32(entryCurrent["StatusInfo"]); 
                 cpuInfo.Stepping = entryCurrent["Stepping"].ToString(); 
                 cpuInfo.SystemCreationClassName = entryCurrent["SystemCreationClassName"].ToString(); 
                 cpuInfo.SystemName = entryCurrent["SystemName"].ToString(); 
                 cpuInfo.UniqueId = entryCurrent["UniqueId"].ToString(); 
                 cpuInfo.UpgradeMethod = Convert.ToInt32(entryCurrent["UpgradeMethod"]); 
                 cpuInfo.Version = entryCurrent["Version"].ToString(); 
                 cpuInfo.VoltageCaps = Convert.ToInt32(entryCurrent["VoltageCaps"]); 
                 if (cpuInfo.Role == "CPU") 
                   listCPUs.Add(cpuInfo); 
           }
           return (Win32_Processor)listCPUs[index]; 
         } 
    }
}
