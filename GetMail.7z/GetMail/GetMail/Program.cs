﻿using EAGetMail;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetMail
{
    class Program
    {
        static void Main(string[] args)
        {
            MailClient oClient = new MailClient("TryIt");

            MailServer oServer = new MailServer("imap.gmail.com",
                "visual.starman@gmail.com", "ya29.Glv4BKslf4B0US9IlTQdZ6LozYcl-nCg8BJkn9DHeC0dfglF-WlKDVaSFdpQYLGF-z4EPxxmr94PrM6Ttm7IgulZhhNDCPFGWW9gz34CTPKt57-LtRpJ_zzE8XcN", true,
                ServerAuthType.AuthXOAUTH2, ServerProtocol.Imap4);

            //IMAP4 SSL port
            oServer.Port = 993;
            try
            {
                oClient.Connect(oServer);
                MailInfo[] infos = oClient.GetMailInfos();
                int count = infos.Length;
                for (int i = 0; i < count; i++)
                {
                    MailInfo info = infos[i];

                    Console.WriteLine("UIDL: {0}", info.UIDL);
                    Console.WriteLine("Index: {0}", info.Index);
                    Console.WriteLine("Size: {0}", info.Size);

                    Console.WriteLine("Flags: {0}", info.IMAP4MailFlags);
                    Console.WriteLine("Read: {0}", info.Read);
                    Console.WriteLine("Deleted: {0}", info.Deleted);

                    Mail oMail = oClient.GetMail(info);
                    //Save mail to local file
                    oMail.SaveAs(String.Format("c:\\{0}.eml", i), true);
                }


                oClient.Quit();
            }
            catch (Exception ep)
            {
                Console.WriteLine("System Error: {0}", ep.Message);
            }

            oClient.Close();
        }
    }
}
