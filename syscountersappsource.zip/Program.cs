using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;

namespace SysCounters
{
    static class Program
    {

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.ThreadException += new ThreadExceptionEventHandler(Application_ThreadException);
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(AppDomain_UnhandledException);
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new frmMainForm());
            }
            catch (Exception ex)
            {
                // use our own exception message dialog instead of the default one
                HandleException(ex);
            }
        }

        public static void HandleException(Exception ex)
        {
            MessageDlg.Error(String.Format("{0}:{1}", ex.ToString(), ex.Message),
                String.Format("{0} : Exception", Application.ProductName));
        }

        public static void HandleException(string exMessage)
        {
            MessageDlg.Error(exMessage, String.Format("{0} : Exception", Application.ProductName));
        }

        //both of these need to be handled so the default Windows exception dialog isn't shown instead
        private static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
        {
            //MessageDlg.Error(e.Exception.Message, "Error: Application.ThreadException");
            HandleException(e.Exception.Message);
            Application.Exit();
        }

        private static void AppDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            //MessageDlg.Error(e.ExceptionObject.ToString(), "Error: Application.ThreadException");
            HandleException(e.ExceptionObject.ToString());
            Application.Exit();
        }

    }
}