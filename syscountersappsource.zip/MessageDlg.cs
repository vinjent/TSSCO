using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

//namespace RAV.WinUtils
namespace System.Windows.Forms
{
    /// <summary>
    /// Convenience methods wrapped around the MessageBox.Show() calls to provide formatted
    /// "error", "confirmation" and "notification" dialog boxes
    /// </summary>
    public static class MessageDlg
    {
        /// <summary>
        /// MessageBox with "Info" icon and OK button (i.e., notify of an input validation error)
        /// </summary>
        /// <param name="message">notification message string</param>
        /// <returns>DialogResult.OK</returns>
        public static DialogResult Notify(string message)
        {
            return MessageBox.Show(message, "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public static DialogResult Notify(string message, string caption)
        {
            return MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// MessageBox with "Error" icon and OK button (i.e., an exception/error message)
        /// </summary>
        /// <param name="message">error message string</param>
        /// <returns>DialogResult.OK</returns>
        public static DialogResult Error(string message)
        {
            return MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public static DialogResult Error(string message, string caption)
        {
            return MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        /// <summary>
        /// MessageBox with "Question" icon and Yes/No buttons (i.e., a confirmation prompt)
        /// </summary>
        /// <param name="message">confirmation message string</param>
        /// <returns>DialogResult</returns>
        public static DialogResult Confirm(string message)
        {
            return MessageBox.Show(message, "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        }

        public static DialogResult ShowMessage(string message, string caption)
        {
            return MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.None);
        }

    }
}
